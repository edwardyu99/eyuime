
 Please Right-Click on "Install_CPIME.INF" file and run "Install".

