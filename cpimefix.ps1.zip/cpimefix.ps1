$LangList = Get-WinUserLanguageList
$LangList.Where({$_.LanguageTag -eq "zh-Hant-HK"}).InputMethodTips[0].Add({0C04:E03D0C04})
Set-WinUserLanguageList -LanguageList $LangList
