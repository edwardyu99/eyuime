#!/system/bin/sh
cp -rf /sdcard/Download/default.yaml /sdcard/rimeCan/'
cp -rf /sdcard/Download/default.cust.yaml /sdcard/rimeCan/'
cp -rf /sdcard/Download/renee.prism.bin /sdcard/rimeCan/build/'
cp -rf /sdcard/Download/renee.reverse.bin /sdcard/rimeCan/build/'
cp -rf /sdcard/Download/renee.schema.yaml /sdcard/rimeCan/build/'
cp -rf /sdcard/Download/renee.table.bin /sdcard/rimeCan/build/
